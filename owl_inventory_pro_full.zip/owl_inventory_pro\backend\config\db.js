const oracledb = require('oracledb');
require('dotenv').config();

// For Oracle 10g, we typically need thick mode. If the user has Oracle Instant Client in their PATH,
// uncommenting the line below might be necessary. We will try default Thin mode first (works for 12c+),
// but we'll add a fallback note for 10g.
try {
  oracledb.initOracleClient(); // Enable thick mode for older DBs if Instant Client is installed
} catch (err) {
  console.log('Oracledb thick mode failed to initialize or not needed:', err.message);
}

const dbConfig = {
  user: process.env.ORACLE_USER,
  password: process.env.ORACLE_PASSWORD,
  connectString: process.env.ORACLE_CONNECTION_STRING
};

async function getConnection() {
  try {
    const connection = await oracledb.getConnection(dbConfig);
    return connection;
  } catch (err) {
    console.error('Error connecting to Oracle DB:', err);
    throw err;
  }
}

async function executeSql(sql, binds = [], options = {}) {
  let connection;
  try {
    connection = await getConnection();
    options.outFormat = oracledb.OUT_FORMAT_OBJECT; // Return rows as objects
    options.autoCommit = options.autoCommit !== false; // Default to true for DML
    const result = await connection.execute(sql, binds, options);
    return result;
  } catch (err) {
    console.error('SQL Execution Error:', err);
    throw err;
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
}

module.exports = {
  getConnection,
  executeSql,
  oracledb
};
